package com.example.yukiat.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    // to make our alarm manager
    AlarmManager alarm_manager;
    TimePicker alarm_timepicker;
    TextView update_text;
    Context context;
    PendingIntent pending_intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.context = this;

        //initialise our alarm manager
        alarm_manager = (AlarmManager)getSystemService(ALARM_SERVICE);

        // initialise our timepicker
        alarm_timepicker = (TimePicker)findViewById(R.id.timePicker);

        // initialise our text update box
        update_text = (TextView)findViewById(R.id.update_text);

        // create an instance of a calendar
        final Calendar calendar = Calendar.getInstance();

        // create an intent to the Alarm Receiver class
        final Intent my_intent = new Intent(this.context, AlarmReceiver.class);

        // initialise the start button
        Button alarm_on = (Button)findViewById(R.id.alarm_on);

        // create an onClick listener to start the alarm
        alarm_on.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                int hour;
                int minute;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    // setting calendar instance with the hour and minute that we picked
                    // on the time picker
                    calendar.set(Calendar.HOUR_OF_DAY, alarm_timepicker.getHour());
                    calendar.set(Calendar.MINUTE, alarm_timepicker.getMinute());

                    // get the string values of the hour and minute
                    hour = alarm_timepicker.getHour();
                    minute = alarm_timepicker.getMinute();
                } else {
                    // setting calendar instance with the hour and minute that we picked
                    // on the time picker
                    calendar.set(Calendar.HOUR_OF_DAY, alarm_timepicker.getCurrentHour());
                    calendar.set(Calendar.MINUTE, alarm_timepicker.getCurrentMinute());

                    // get the string values of the hour and minute
                    hour = alarm_timepicker.getCurrentHour();
                    minute = alarm_timepicker.getCurrentMinute();
                }
                //convert the int values to strings
                String hour_string = String.valueOf(hour);
                String minute_string = String.valueOf(minute);

                // convert 24hour time to 12hour time
                if (hour > 12) {
                    hour_string = String.valueOf(hour - 12);
                }

                if (minute < 10) {
                    minute_string = "0" + String.valueOf(minute);
                }

                // method that changes the update text Textbox
                set_alarm_text("Alarm set to: " + hour_string + ":" + minute_string);

                // create a pending intent that delays the intent
                // until the specified calendar time
                pending_intent = PendingIntent.getBroadcast(MainActivity.this, 0, my_intent,
                        PendingIntent.FLAG_UPDATE_CURRENT);

                // set the alarm manager
                alarm_manager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                        pending_intent);

            }
        });

        // initialise the stop button
        Button alarm_off = (Button)findViewById(R.id.alarm_off);
        //create an onClick listener to stop the alarm or undo an alarm set

        alarm_off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                set_alarm_text("Alarm off!");

                // cancel the alarm
                alarm_manager.cancel(pending_intent);
            }
        });
    }

    private void set_alarm_text(String output) {
        update_text.setText(output);
    }
}
